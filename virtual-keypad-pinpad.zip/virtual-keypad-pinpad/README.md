# PINpad
An interactive PIN-pad created using jQuery
# Screenshot
<img width="853" alt="Screenshot 2020-11-30 185618" src="https://user-images.githubusercontent.com/72983747/100626502-56f84700-333f-11eb-980b-638b0401f373.png">
